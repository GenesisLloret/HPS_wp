<?php
$mod_name = "Example Module";
$mod_version = "1.0";
$mod_description = "This is an example module.";
$mod_author = "Génesis Lloret Ramos";
$mod_always_enabled = false;
$mod_menu = true;
$mod_has_options = ["update", "activate"];
$mod_WSForm_moderation = true;